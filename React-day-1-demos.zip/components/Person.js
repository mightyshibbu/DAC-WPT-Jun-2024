let Person = (props) => {
    return <h1>Hello {props.name}. I am {props.age} years old</h1>
}

export default Person