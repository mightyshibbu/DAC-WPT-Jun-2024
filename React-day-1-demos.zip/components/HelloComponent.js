import React from 'react'

const HelloComponent = (props) => {
  return (
    <div>Hello {props.username}</div>
  )
}

export default HelloComponent