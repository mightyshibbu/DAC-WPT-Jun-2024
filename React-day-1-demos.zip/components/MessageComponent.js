import React from 'react'
import HelloComponent from './HelloComponent'

const MessageComponent = () => {
    return (
        <div><h2>MessageComponent</h2>
            <HelloComponent username="shrilata"/>
        </div>
    )
}

export default MessageComponent