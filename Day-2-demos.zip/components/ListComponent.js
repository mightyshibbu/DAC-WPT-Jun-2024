import React from 'react'

const ListComponent = () => {

   let arr = [1,2,3,4,5]
   let newarr = arr.map(num=>{
      return <li>{num*num}</li>
   })

   let items = [
    {id:101, iname:"aaa", price:200},
    {id:102, iname:"bbb", price:300},
    {id:103, iname:"ccc", price:250}
   ]

   let itable = items.map(item =>(
     <tr><td>{item.id}</td><td>{item.iname}</td><td>{item.price}</td></tr>
   ))

  /* let updatedItems = items.map(item=>(
    <p>{item.iname}</p>
   ))*/

  return (
    <div>
        ListComponent
        {newarr}
       <table border='1'>
        {itable}
       </table>
    </div>
  )
}

export default ListComponent