import React, { useState } from 'react'

const SimpleForm = () => {

    let [uname, setUname] = useState("")
    let [pass, setPass] = useState("")

   let unameHandler = (e) => {
        setUname(e.target.value)
   }

   let passHandler = (e) => {
    setPass(e.target.value)
  }

let submitHandler = (e)=>{
    e.preventDefault()
    let user = {
        username:uname,
        password : pass
    }
console.log(user)
setUname("")
setPass("")
}

  return (
    <div>
        <form onSubmit={submitHandler}>
            Username : <input onChange={unameHandler} value={uname}/> <br />
            Password : <input onChange={passHandler} value={pass}/> <br />
            <input type="submit" />
        </form>
    </div>
  )
}

export default SimpleForm