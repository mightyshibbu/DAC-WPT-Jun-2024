import React, { useState } from 'react'

const Child = (props) => {

  let [cname, setName] = useState("Yugal")

  return (
    <div>
        Child
       {props.onData(cname)}
    </div>
  )
}

export default Child