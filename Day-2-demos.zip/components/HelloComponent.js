import React from 'react'

const HelloComponent = (props) => {
  return (
    <div>Hello {props.username} {props.message}, your mail id is {props.email}</div>
  )
}

export default HelloComponent