import React, { useState } from 'react'
import HelloComponent from './HelloComponent'

const MessageComponent = () => {

    let [uname, setUname] = useState("Shrilata")
    let [msg, setMsg] = useState("Welcome to React")

    let email = "shrilata@gmail.com"

    return (
        <div><h2>MessageComponent</h2>
            <HelloComponent username={uname} message={msg} email = {email}/>
        </div>
    )
}

export default MessageComponent