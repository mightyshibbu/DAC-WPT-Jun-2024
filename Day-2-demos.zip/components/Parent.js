import React from 'react'
import Child from './Child'

const Parent = () => {

   let f1 = (data)=>{
    console.log("in parent, data from child",data)
   }

  return (
    <div>
        Parent
        <Child onData={f1}/>
    </div>
  )
}

export default Parent