import { useState } from 'react'
import ExpenseDate from './ExpenseDate'
import './ExpenseItem.css'

let ExpenseItem = (props) => {

    //let title = props.expTitle
    let [title, setTitle] = useState(props.expTitle)

    let btnHandler = ()=>{
       setTitle("Updated Title")
    }

    return (
        <div className="expense-item">
           <div><ExpenseDate expDate={props.expDate}/></div>
            <div className="expense-item__description">
                <h2>{title}</h2>
                <p className="expense-item__price">Rs {props.expAmount}</p>
            </div>
            <button onClick={btnHandler}>Change Title</button>
        </div>

    )
}

export default ExpenseItem